UPDATE personne SET etat = 7, presenceListeCeni = '0' WHERE id = 'DBV005074';
UPDATE personne SET etat = 7, presenceListeCeni = '0' WHERE id = 'DBV005113';
UPDATE personne SET etat = 7, presenceListeCeni = '0' WHERE id = 'DBV005150';
UPDATE personne SET etat = 7, presenceListeCeni = '0' WHERE id = 'DBV005169';
