UPDATE personne SET etat = 7, presenceListeCeni = '0' WHERE id = 'DBV004709';
UPDATE personne SET etat = 7, presenceListeCeni = '0' WHERE id = 'DBV004722';
